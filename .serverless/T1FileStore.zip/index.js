const db = require("./db");
const serverless = require("serverless-http");
const bodyParser = require("body-parser");
const express = require("express");
const app = express();
const tus = require("tus-node-server");
const server = new tus.Server();
const uploadApp = express();
const EVENTS = require("tus-node-server").EVENTS;
const BucketName = "t1filestore";
const IS_OFFLINE = process.env.IS_OFFLINE;
const secret = process.env.IS_OFFLINE ? require("./secrets") : {};
const { jwtVerify } = require("./security");
const { base64_decode } = require("./JWT");
var isNotTest = typeof global.it === "function";

const driverRoute = require("./routes/driver");
const userRoute = require("./routes/user");
const companyRoute = require("./routes/company")
const orderRoute = require("./routes/order")
const invoiceRoute = require("./routes/invoice")

app.get("/", (req, res) => {
  res.send("T1-File-Storage Serverless APP");
});
app.use(bodyParser.json({ strict: false }));

const authenticateRequests = (req, res, next) => {
  jwtVerify(req.headers)
    .then((decodedData) => {
      req.decodedData = decodedData;
      next();
    })
    .catch((err) => {
      res.status(401).json({ message: "Unauthorized!" });
    });
};

//app.use(authenticateRequests);

app.use("/upload", uploadApp);

// restaurant Endpoint
app.use("/driver", driverRoute);
app.use("/user", userRoute);
app.use("/campany", companyRoute);
app.use("/order", orderRoute)
app.use("/invoice", invoiceRoute);

app.post("/driver", (req, res) => {
  let resp = driverController.create(req.body);
  res.json(resp);
  //   console.log(req.body);
  //   db.createFileDetails(req.body + "")
  //     .then((fileDetails) => {
  //       res.json(fileDetails);
  //     })
  //     .catch((error) => {
  //       res.status(error.code).json(error);
  //     });
});

app.post("/create-file-detail-test", (req, res) => {
  db.createFileDetails(req.body + "")
    .then((fileDetails) => {
      res.json(fileDetails);
    })
    .catch((error) => {
      res.status(error.code).json(error);
    });
});

app.get("/files/:id", (req, res) => {
  db.getFileById(req.params.id)
    .then((file) => {
      res.json(file);
    })
    .catch((error) => {
      res.status(error.code).json(error);
    });
});

// server.datastore = new tus.S3Store({
//     path: '/files',
//     bucket: BucketName,
//     accessKeyId: (IS_OFFLINE) ? secret.ACCESS_KEY_ID : process.env.ACCESS_KEY_ID,
//     secretAccessKey:  (IS_OFFLINE) ? secret.SECRET_KEY : process.env.SECRET_KEY,
//     region: 'eu-west-3',
//     partSize: 0, // each uploaded part will have ~8MB,
//     tmpDirPrefix: 'tus-s3-store',
// });

// server.on(EVENTS.EVENT_ENDPOINT_CREATED, (event) => {
// });

// server.on(EVENTS.EVENT_FILE_CREATED, (event) => {
// });

// server.on(EVENTS.EVENT_UPLOAD_COMPLETE, (event) => {

//     db.createFileDetails({
//         fileId : event.file.id,
//         date : new Date().getTime(),
//         userId : base64_decode(event.file.upload_metadata.split(',')[2].split(' ')[1]),
//         fileName : base64_decode(event.file.upload_metadata.split(',')[0].split(' ')[1]),
//         fileType : base64_decode(event.file.upload_metadata.split(',')[1].split(' ')[1])
//     });
// });

uploadApp.all("*", server.handle.bind(server));

module.exports.handler = serverless(app);
